# SmartSlope Website Prototype

## Included
- `index.html`: responsive dashboard with three moisture zones, demo irrigation controls, weather forecast, runoff status, recommendations, graphs, CSV export, and Kannada text-to-speech.
- Works in demo mode without hardware. The weather forecast requires an internet connection.
- Chart.js is loaded from a CDN, so charts require internet.

## Run it
1. Extract the ZIP.
2. Open `index.html` in a modern browser.
3. Allow internet access for weather and charts.
4. Change latitude/longitude to the demonstration farm location and press **Save settings**.
5. Use **Run demo cycle** to demonstrate the dashboard. Demo readings are simulated.

For best browser behavior, run it from a local development server instead of double-clicking the file:
- Install Python if needed.
- Open a terminal in this folder and run: `python -m http.server 8000`
- Visit `http://localhost:8000`.

## Important: hardware connection
This website does NOT automatically connect to the ESP32 until firmware implementing the API endpoints below is added. In the settings, enter the ESP32 local URL, such as `http://192.168.1.50`, and choose **Test ESP32 connection**.

### Expected API contract
`GET /api/status` should return JSON similar to:
```json
{
  "zones": [
    {"id": 1, "name": "Upper zone", "moisture": 28, "valve": false, "water": 0},
    {"id": 2, "name": "Middle zone", "moisture": 48, "valve": false, "water": 0},
    {"id": 3, "name": "Lower zone", "moisture": 72, "valve": false, "water": 0}
  ],
  "runoff": false,
  "flowRate": 0,
  "totalWater": 0
}
```
The website can display zone values from this endpoint. Add the other fields in your ESP32 firmware if you want the page to show live flow, total water and runoff status too.

`POST /api/control` accepts JSON such as:
```json
{"zone": 1, "open": true}
```
or
```json
{"action": "auto_cycle"}
```
The ESP32 firmware must validate requests and enforce safety rules. Do not rely on website code alone for pump/valve safety.

### Browser connection notes
- The phone/computer and ESP32 generally need to be on the same Wi-Fi network for a local URL.
- ESP32 firmware must enable CORS for the dashboard's origin if required by the browser.
- Browsers may block HTTP requests from an HTTPS-hosted page to a local HTTP device. Serve the page locally over HTTP for a simple prototype, or use a secure gateway.
- Do not expose the ESP32 control endpoint directly to the public internet.
- The dashboard uses simulated sample values by default; sample values are not real measurements.

## Weather
The website uses the Open-Meteo forecast API. Update latitude and longitude for the demo farm. Weather forecasts are advisory and do not replace the local rain sensor.

## Kannada voice
The website uses browser speech synthesis with language `kn-IN`. Whether a Kannada voice is installed depends on the device/browser. If unavailable, use recorded Kannada audio clips or an alternate text-to-speech service.

## Safety
- Keep a physical emergency stop.
- ESP32 firmware must stop irrigation on runoff, sensor failure, excessive runtime, or abnormal flow.
- Use appropriate MOSFET/relay drivers and flyback protection for valves/pumps.
- Calibrate moisture sensors in the actual soil before setting thresholds.
